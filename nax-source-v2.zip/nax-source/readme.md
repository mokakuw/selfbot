# steps:
download python & node.js
if missing dependencies, install them
open config.txt and name your token & preferences

# reqs:
python 3.8+
node

# gl, -nax <3
